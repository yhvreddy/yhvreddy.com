<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\DefaultModel;
use DB;
class ContactusModel extends DefaultModel
{
    //
}
