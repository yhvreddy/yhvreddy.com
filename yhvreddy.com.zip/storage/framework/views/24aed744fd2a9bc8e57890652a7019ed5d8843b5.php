<!DOCTYPE html>
<html lang="zxx" class="no-js">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="shortcut icon" href="img/fav.png">
  <meta name="author" content="colorlib">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta charset="UTF-8">
  <title><?php echo $__env->yieldContent('page_title'); ?></title>
  <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700,900" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/linearicons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/font-awesome.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/magnific-popup.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/nice-select.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/animate.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/owl.carousel.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/main.css')); ?>">
  <script src="<?php echo e(asset('public/js/vendor/jquery-2.2.4.min.js')); ?>"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
    .about-content {
      margin-top: 100px;
      margin-bottom: 60px;
      text-align: center;
    }
     .fa{
         font-size: 30px;
     }
  </style>
</head>

<body>

  <div class="preloader-area">
    <div class="loader-box">
      <div class="loader"></div>
    </div>
  </div>


<header id="header">
    <div class="container main-menu">
        <div class="row align-items-center d-flex">
            <div id="logo">
            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset($aboutdetails[0]->logo)); ?>" alt="" title="" /></a>
            </div>
            <nav id="nav-menu-container">
                <ul class="nav-menu">
                    <li class=""><a class="active" href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a href="<?php echo e(url('/aboutus')); ?>">About Me</a></li>
                    <li><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                    <li><a href="<?php echo e(url('/portfolio')); ?>">Projects</a></li>
                
                </ul>
            </nav>
        </div>
    </div>
</header>

<?php echo $__env->yieldContent('content_box'); ?>

<footer class="footer-area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="footer-top flex-column">
                    <div class="footer-logo">
                    <a href="#">
                        <!-- <img src="<?php echo e(asset($aboutdetails[0]->logo)); ?>" alt=""> -->
                    </a>
                    <h4>Follow Me</h4>
                </div>
                <div class="footer-social">
                    <a href="<?php echo e($aboutdetails[0]->facebook); ?>" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="<?php echo e($aboutdetails[0]->twitter); ?>" target="_blank"><i class="fa fa-twitter"></i></a>
                    <a href="<?php echo e($aboutdetails[0]->linkedin); ?>" target="_blank"><i class="fa fa-linkedin"></i></a>
                    <a href="<?php echo e($aboutdetails[0]->instagram); ?>" target="_blank"><i class="fa fa-instagram"></i></a>
                    <a href="<?php echo e($aboutdetails[0]->github); ?>" target="_blank"><i class="fa fa-github"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="row footer-bottom justify-content-center">
        <p class="col-lg-8 col-sm-12 footer-text">
            Copyright &copy;
            <script>document.write(new Date().getFullYear());</script> All
            rights reserved.
        </p>
    </div>
</footer>


  <div id="back-top">
    <a title="Go to Top" href="#">
      <i class="fa fa-arrow-up"></i>
    </a>
  </div>

  <script src="../../../../cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" crossorigin="anonymous"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"></script>
  <script src="<?php echo e(asset('public/js/vendor/bootstrap.min.js')); ?>"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  <script src="<?php echo e(asset('public/js/easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/hoverIntent.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/superfish.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/mn-accordion.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/jquery.ajaxchimp.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/jquery.magnific-popup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/jquery.nice-select.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/jquery.circlechart.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/mail-script.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/wow.min.js')); ?>"></script>
  <script src="<?php echo e(asset('public/js/main.js')); ?>"></script>
  <script src="../../../../ajax.cloudflare.com/cdn-cgi/scripts/95c75768/cloudflare-static/rocket-loader.min.js"
    data-cf-settings="2ca6b7374245c00428887a5f-|49" defer=""></script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\yhvreddy.com\resources\views/website_layout.blade.php ENDPATH**/ ?>