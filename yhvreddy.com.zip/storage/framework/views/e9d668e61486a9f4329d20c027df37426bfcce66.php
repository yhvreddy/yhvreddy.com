<?php $__env->startSection('page_title','Project List'); ?>
<?php $__env->startSection('content_box'); ?>
<div class="row">

    <div class="col-12 col-md-12 col-lg-12">
        <div class="card">
            
            <div class="card-header">
                <h4>Project's List</h4>
            </div>
            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped datatable" id="table-1">
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th></th>
                            <th>Project Name</th>
                            <th>Duration</th>
                            <th>On Position</th>
                            <th>Started Date</th>
                            <th>Project Mode</th>
                            <th>Client Name</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td>
                                    <img src="<?php echo e(asset($project->project_cover_img)); ?>" style="border-radius:50%;width:30px;height:30px">
                                </td>
                                <td><a href="#"><?php echo e($project->project_name); ?></a></td>
                                <td><?php echo e($project->project_duration); ?></td>
                                <td>
                                    <?php $type = DB::table('portfolio_formdata')->where('short_name',$project->project_type)->get(); ?>
                                    <?php echo e($type[0]->name); ?>

                                </td>
                                <td><?php echo e(date('d-m-Y',strtotime($project->start_date))); ?></td>
                                <td><?php echo e(ucfirst($project->project_mode)); ?></td>
                                <td>
                                    <?php if(!empty($project->client_name)): ?>
                                        <?php echo e(ucwords($project->client_name)); ?>

                                    <?php else: ?>
                                        ---
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="#" onclick="return confirm('You want to edit project <?php echo e($project->project_name); ?> details.?')"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
                                    <a href="<?php echo e(url('/home/project/'.$project->id.'/delete')); ?>" onclick="return confirm('You want to delete project <?php echo e($project->project_name); ?> details.?')"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yhvreddy.com\resources\views/admin/projectList.blade.php ENDPATH**/ ?>