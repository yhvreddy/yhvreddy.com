<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(url('/home')); ?>"> <img alt="image" src="<?php echo e(asset('public/assets/img/logo.png')); ?>" class="header-logo"> <span class="logo-name">Yhvreddy</span>
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown">
            <a href="<?php echo e(url('/home')); ?>" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>
            <!-- <li class="dropdown">
                <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="briefcase"></i><span>Widgets</span></a>
                <ul class="dropdown-menu">
                    <li><a class="nav-link" href="widget-chart.html">Chart Widgets</a></li>
                    <li><a class="nav-link" href="widget-data.html">Data Widgets</a></li>
                </ul>
            </li> -->
            <li><a class="nav-link" href="<?php echo e(url('/home/addskills')); ?>"><i class="fa fa-bolt" ></i><span>Skills</span></a></li>
            <li><a class="nav-link" href="<?php echo e(url('/home/services')); ?>"><i class="fa fa-bars" ></i></i><span>Services</span></a></li>

            <li class="dropdown">
                <a href="#" class="menu-toggle nav-link has-dropdown"><i class="fa fa-box-open"></i><span>Projects</span></a>
                <ul class="dropdown-menu">
                    <li><a class="nav-link" href="<?php echo e(url('/home/addproject')); ?>">Add Projects</a></li>
                    <li><a class="nav-link" href="<?php echo e(url('/home/projectlist')); ?>">Projects List</a></li>
                </ul>
            </li>

            <li><a class="nav-link" href="<?php echo e(url('/home/education')); ?>"><i class="fa fa-book-reader" ></i><span>Education</span></a></li>
            <li><a class="nav-link" href="<?php echo e(url('/home/experence')); ?>"><i class="fa fa-briefcase" ></i><span>Experiences</span></a></li>
            <li><a class="nav-link" href="<?php echo e(url('/home/aboutus')); ?>"><i class="fa fa-user" ></i><span>About us</span></a></li>
        </ul>
    </aside>
</div><?php /**PATH D:\xampp\htdocs\yhvreddy.info\resources\views/layouts/menu.blade.php ENDPATH**/ ?>