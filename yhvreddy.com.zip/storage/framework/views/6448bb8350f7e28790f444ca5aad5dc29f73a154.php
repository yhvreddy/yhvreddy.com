<?php if(count($aboutdetails) != 0): ?>
    
    <?php $__env->startSection('page_title','Portfolio Details : : yhvreddy'); ?>
    <?php $__env->startSection('content_box'); ?> 
        <section class="banner-area relative">
            <div class="container">
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Portfolio
                        </h1>
                        <p class="link-nav">
                            <span class="box">
                                <a href="<?php echo e(url('/')); ?>">Home </a>
                                <a href="<?php echo e(url('/portfolio')); ?>">Portfolio</a>
                                <a href="#">Portfolio Details</a>
                            </span>
                        </p>    
                    </div>
                </div>
            </div>
        </section>
        
        <?php if(count($projectdetails) != 0): ?>
            <section class="portfolio_details_area section-gap">
                <div class="container">
                    <div class="portfolio_details_inner">
                        <div class="row d-flex justify-content-between align-items-end mb-80">
                            <div class="col-lg-12">
                                <div class="section-title">
                                    <h2><?php echo e($projectdetails[0]->project_name); ?> Project Details</h2>
                                    <!-- <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price. You may see
                                        some for as low as $.17 each.</p> -->
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="left_img">
                                        <?php if(!empty($projectdetails[0]->project_cover_img)): ?>
                                            <img class="image img-fluid" src="<?php echo e(asset($projectdetails[0]->project_cover_img)); ?>" alt="<?php echo e($projectdetails[0]->project_name); ?>">
                                        <?php else: ?>
                                            <img class="image img-fluid" src="<?php echo e(asset('public/img/project_img.jpg')); ?>" alt="">
                                        <?php endif; ?>
                                </div>
                            </div>
                            
                            
                            <div class="offset-md-1 col-md-5">
                                <div class="portfolio_right_text mt-30">
                                    <h4><?php echo e($projectdetails[0]->project_name); ?></h4>
                                    <p><?php echo e($projectdetails[0]->mini_content); ?></p>
                                    <ul class="list">
                                        <?php if($projectdetails[0]->project_mode == 'freelancer'): ?>
                                            <li><span>Client</span>: <?php echo e($projectdetails[0]->client_name); ?></li>
                                        <?php endif; ?>
                                        <li>
                                            <span>Website</span> : 
                                            <?php if(!empty($projectdetails[0]->project_link)): ?>
                                                <a href="<?php echo e($projectdetails[0]->project_link); ?>"> <?php echo e($projectdetails[0]->project_name); ?> Link </a>
                                            <?php endif; ?>
                                        </li>
                                        <li>
                                            <span>Completed</span> : 
                                            <?php echo e(date('d M Y',strtotime($projectdetails[0]->end_date))); ?>

                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <?=$projectdetails[0]->project_content?>
                        </div>

                    </div>
                </div>
            </section>
        <?php endif; ?>

        <section class="contact-area section-gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="contact-title">
                            <h2>Contact Me</h2>
                            <!-- <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price. You may see some for as low as $.17 each.</p> -->
                        </div>
                    </div>
                </div>
                <div class="row mt-80">
                    <div class="col-lg-4 col-md-4">
                        <div class="contact-box">
                            <h4>+91 <?php echo e($aboutdetails[0]->mobile); ?></h4>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4">
                        <div class="contact-box">
                            <h4><a href="mailto:<?php echo e($aboutdetails[0]->mobile); ?>" class="text-white"><?php echo e($aboutdetails[0]->email); ?></a></h4>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4">
                        <div class="contact-box">
                            <h4>www.yhvreddy.info</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <a href="<?php echo e(url('/contactus')); ?>" class="primary-btn mt-50" data-text="Hire Me">
                            <span>H</span>
                            <span>i</span>
                            <span>r</span>
                            <span>e</span>
                            <span> </span>
                            <span>M</span>
                            <span>e</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>


    <?php $__env->stopSection(); ?>
<?php else: ?>

<?php endif; ?>
<?php echo $__env->make('website_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yhvreddy.com\resources\views/portfoliodetails_page.blade.php ENDPATH**/ ?>