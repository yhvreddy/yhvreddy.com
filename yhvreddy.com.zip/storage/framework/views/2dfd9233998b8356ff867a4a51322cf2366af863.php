<?php if(count($aboutdetails) != 0): ?>
    
    <?php $__env->startSection('page_title','Services : : yhvreddy'); ?>
    <?php $__env->startSection('content_box'); ?>    
        <section class="banner-area relative">
            <div class="container">
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Services
                        </h1>
                        <p class="link-nav">
                        <span class="box">
                            <a href="<?php echo e(url('/')); ?>">Home </a>
                            <a href="<?php echo e(url('/services')); ?>">Service</a></p>
                        </span>
                    </div>
                </div>
            </div>
        </section>

        <?php if(count($services)): ?>
            <section class="service-area section-gap white">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title">
                                <h2>Service Offers</h2>
                                <!-- <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price. You may see some for as low as $.17 each.</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <?php $bg = array('#e2a599','#715f69','#e45447','#90acd1'); ?>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="single-service wow fadeInUp" data-wow-duration="1s">
                                    <?php if(!empty($service->service_icon)): ?>
                                        <span class="<?php echo e($service->service_icon); ?>"></span>
                                        <?php else: ?>
                                        <img src="<?php echo e(asset($service->service_image)); ?>" style="width:50px;height:50px">
                                    <?php endif; ?>    
                                    <h4>
                                        <span><?php echo e($service->service_name); ?></span>
                                    </h4>
                                    <p><?php echo e($service->service_content); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <div class="container">
            <hr>
        </div>

    <?php $__env->stopSection(); ?>
<?php else: ?>

<?php endif; ?>
<?php echo $__env->make('website_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yhvreddy.info\resources\views/services_page.blade.php ENDPATH**/ ?>