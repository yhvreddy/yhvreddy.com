<?php if(count($aboutdetails) != 0): ?>
    
    <?php $__env->startSection('page_title','Welcome My Portfolio'); ?>
    <?php $__env->startSection('content_box'); ?>

        <?php $about = $aboutdetails[0]; ?>

        <section class="home-banner-area">
            <div class="container">
                <div class="row fullscreen d-flex align-items-center">
                    <div class="banner-content col-lg-6 col-md-12 justify-content-center ">
                        <div class="me wow fadeInDown" data-wow-duration="1s" data-wow-delay="1.2s">Hi i'm</div>
                        <h1 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.7s">
                            <?php if(!empty($about->first_name)): ?>
                                <?php echo e($about->first_name.' '.$about->middel_name); ?>

                            <?php else: ?>
                                Persion Name
                            <?php endif; ?>    
                        </h1>
                        <div class="designation mb-50 wow fadeInUp" data-wow-duration="1s" data-wow-delay="2.1s">
                            <?php if(!empty($about->profession)): ?>
                                <?php echo e($about->profession); ?>

                                <span class="developer">Developer..!</span>
                            <?php else: ?>
                                Profession
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(url('/contactus')); ?>" class="primary-btn" data-text="Hire Me">
                            <span>Hire Me</span>
                        </a>
                    </div>
                    <div class="banner-img col-lg-6 col-md-6 align-self-end">
                        <?php if(!empty($about->banner_img)): ?>
                            <img class="img-fluid" src="<?php echo e(asset($about->banner_img)); ?>" alt="Banner Image : yhvreddy">
                        <?php endif; ?>    
                    </div>
                </div>
            </div>
        </section>


        <section class="brands-area">
            <div class="container">
                <div class="brand-wrap">
                    <div class="row align-items-center active-brand-carusel justify-content-start no-gutters">
                        <div class="col single-brand">
                            <a href="#"><img class="mx-auto" src="<?php echo e(asset('public/img/brand/b1.png')); ?>" alt=""></a>
                        </div>
                        <div class="col single-brand">
                            <a href="#"><img class="mx-auto" src="<?php echo e(asset('public/img/brand/b2.png')); ?>" alt=""></a>
                        </div>
                        <div class="col single-brand">
                            <a href="#"><img class="mx-auto" src="<?php echo e(asset('public/img/brand/b3.png')); ?>" alt=""></a>
                        </div>
                        <div class="col single-brand">
                            <a href="#"><img class="mx-auto" src="<?php echo e(asset('public/img/brand/b4.png')); ?>" alt=""></a>
                        </div>
                        <div class="col single-brand">
                            <a href="#"><img class="mx-auto" src="<?php echo e(asset('public/img/brand/b5.png')); ?>" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section class="about-area section-gap">
            <div class="container">
                <div class="row align-items-center justify-content-between">
                    <div class="col-lg-6 about-left">
                        <?php if(!empty($about->about_img)): ?>
                            <img class="img-fluid" src="<?php echo e(asset($about->about_img)); ?>" alt="<?php echo e($about->first_name); ?>, Harshavardhan Reddy, Yenumula, yhvreddy">
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-5 col-md-12 about-right">
                        <div class="section-title">
                            <h2>about myselt</h2>
                        </div>
                        <div class="mb-50 wow fadeIn" data-wow-duration=".8s">
                            <?php if(!empty($about->short_description)): ?>
                                <?=$about->short_description?>
                            <?php else: ?>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
                                </p>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
                                </p>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(url('/aboutus')); ?>" class="primary-btn white" data-text="More Info">
                            <span>M</span>
                            <span>o</span>
                            <span>r</span>
                            <span>e</span>
                            <span> </span>
                            <span>I</span>
                            <span>n</span>
                            <span>f</span>
                            <span>o</span>
                        </a>
                        <?php if(!empty($about->resume)): ?>
                            <a href="<?php echo e(asset($about->resume)); ?>" target="_blank" class="primary-btn" data-text="Resume">
                                <span>R</span>
                                <span>e</span>
                                <span>s</span>
                                <span>u</span>
                                <span>m</span>
                                <span>e</span>
                            </a>
                        <?php endif; ?>    
                    </div>
                </div>
            </div>
        </section>

        <?php if(count($projects) != 0): ?>
            <section class="work-area section-gap-top section-gap-bottom-90" id="work">
                <div class="container">
                    <div class="row d-flex justify-content-between align-items-end mb-80">
                        <div class="col-lg-6">
                            <div class="section-title">
                                <h2>Latest Works</h2>
                                <!-- <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price. You may see
                                    some for as low as $.17 each.</p> -->
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <!-- <div class="filters">
                                <ul>
                                    <li class="active" data-filter=".all">All Categories</li>
                                    <li data-filter=".branding">Branding</li>
                                    <li data-filter=".creative">Creative Work</li>
                                    <li data-filter=".web-design">Web Design</li>
                                </ul>
                            </div> -->
                        </div>
                    </div>
                    <div class="filters-content">
                        <div class="row grid">
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-work col-lg-4 col-md-6 col-sm-12 all filter-name wow fadeInUp" data-wow-duration="2s">
                                    <div class="relative">
                                        <div class="thumb">
                                            <div class="overlay overlay-bg"></div>
                                            <?php if(!empty($project->project_cover_img)): ?>
                                                <img class="image img-fluid" src="<?php echo e(asset($project->project_cover_img)); ?>" alt="<?php echo e($project->project_name); ?>">
                                            <?php else: ?>
                                            <img class="image img-fluid" src="<?php echo e(asset('public/img/project_img.jpg')); ?>" alt="">
                                            <?php endif; ?>    
                                        </div>
                                        <div class="middle">
                                            <h4><?php echo e($project->project_name); ?></h4>
                                            <div class="cat"><?php echo e($project->project); ?></div>
                                        </div>
                                        <a class="overlay" href="<?php echo e(url('/portfolio/'.$project->id.'/details')); ?>"></a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <?php if(count($experences) != 0): ?>
            <section class="job-area section-gap-top section-gap-bottom-90">
                <div class="container">
                    <div class="row d-flex">
                        <div class="col-lg-12">
                            <div class="section-title">
                                <h2>Job History</h2>
                                <!-- <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price. You may see some for as low as $.17 each.</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $experences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6">
                                <div class="single-job">
                                    <div class="top-sec d-flex justify-content-between">
                                        <div class="top-left">
                                            <h4><?php echo e($experence->company_name); ?></h4>
                                            <p><?php echo e($experence->location); ?></p>
                                        </div>
                                        <div class="top-right">
                                            <a href="#" class="primary-btn" data-text="Jul '15 to Present">
                                                <span>J</span><span>u</span><span>l</span>
                                                <span>'</span><span>1</span><span>5</span>
                                                <span>t</span><span>o</span>
                                                <span>P</span><span>r</span><span>e</span><span>s</span><span>e</span><span>n</span><span>t</span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="bottom-sec wow fadeIn" data-wow-duration="2s">
                                        <?php echo e($experence->content); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <?php if(count($services)): ?>
            <section class="service-area section-gap">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title">
                                <h2>Service Offers</h2>
                                <!-- <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price. You may see some for as low as $.17 each.</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <?php $bg = array('#e2a599','#715f69','#e45447','#90acd1'); ?>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="single-service wow fadeInUp" data-wow-duration="1s">
                                    <?php if(!empty($service->service_icon)): ?>
                                        <span class="<?php echo e($service->service_icon); ?>"></span>
                                        <?php else: ?>
                                        <img src="<?php echo e(asset($service->service_image)); ?>" style="width:50px;height:50px">
                                    <?php endif; ?>    
                                    <h4>
                                        <span><?php echo e($service->service_name); ?></span>
                                    </h4>
                                    <p><?php echo e($service->service_content); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>


        <section class="testimonials_area section-gap">
            <div class="container">
                <div class="testi_slider owl-carousel">
                    <div class="item">
                        <div class="testi_item">
                            <img src="<?php echo e(asset('public/img/quote.png')); ?>" alt="">
                            <h4>Srinu.Y</h4>
                            <ul class="list">
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                            </ul>
                            <div class="wow fadeIn" data-wow-duration="1s">
                                <p>
                                    As conscious traveling Paup ers we must always be oncerned about our dear Mother Earth. If you think about it, you travel
                                    across her face <br> and She is the host to your journey.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testi_item">
                            <img src="<?php echo e(asset('public/img/quote.png')); ?>" alt="">
                            <h4>Prasad.L</h4>
                            <ul class="list">
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                            </ul>
                            <div class="wow fadeIn" data-wow-duration="1s">
                                <p>
                                    As conscious traveling Paup ers we must always be oncerned about our dear Mother Earth. If you think about it, you travel
                                    across her face <br> and She is the host to your journey.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testi_item">
                            <img src="<?php echo e(asset('public/img/quote.png')); ?>" alt="">
                            <h4>Bhavya.P</h4>
                            <ul class="list">
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                                <li><a href="#"><i class="fa fa-star"></i></a></li>
                            </ul>
                            <div class="wow fadeIn" data-wow-duration="1s">
                                <p>
                                    As conscious traveling Paup ers we must always be oncerned about our dear Mother Earth. If you think about it, you travel
                                    across her face <br> and She is the host to your journey.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <?php $__env->stopSection(); ?>
<?php else: ?>

<?php endif; ?>
<?php echo $__env->make('website_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yhvreddy.info\resources\views/home_page.blade.php ENDPATH**/ ?>