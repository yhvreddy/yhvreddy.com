<?php $__env->startSection('page_title','Services Details'); ?>
<?php $__env->startSection('content_box'); ?>
<div class="row">
    <div class="col-12 col-md-12 col-lg-12">
        <div class="card">
            <form method="post" action="<?php echo e(url('/home/saveServiceData')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-header">
                    <h4>Add Services</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 form-group">
                            <label>Service Name</label>
                            <input type="text" class="form-control" required="" name="serviceName" placeholder="Service Name">
                        </div>
                        <div class="col-md-4 form-group">
                            <label>Service Image</label>
                            <input type="file" class="form-control" name="serviceImage">
                        </div>
                        <div class="col-md-4 form-group">
                            <label>Service Icon</label>
                            <input type="text" class="form-control" name="serviceIcon" placeholder="Service Icon">
                        </div>
                        <div class="col-md-12 form-group">
                            <label>Service Content</label>
                            <textarea class="form-control" required="" row="6" name="serviceContent" placeholder="Type Service Content..."></textarea>
                        </div>
                    </div>    
                </div>
                <div class="card-footer text-right">
                    <button class="btn btn-primary" type="submit">Save Services</button>
                </div>
            </form>
        </div>
    </div>

    <div class="col-12 col-md-12 col-lg-12">
        <div class="card">
            
            <div class="card-header">
                <h4>Services List</h4>
            </div>
            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped datatable" id="table-1">
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th>Service Name</th>
                            <th>Icon</th>
                            <th>SImage</th>
                            <th>Content</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($service->service_name); ?></td>
                                <td align="center">
                                    <?php if(!empty($service->service_icon)): ?>
                                        <i class="<?php echo e($service->service_icon); ?>" style="font-size: 28px;"></i>
                                    <?php else: ?>
                                        ---
                                    <?php endif; ?>
                                </td>
                                <td align="center">
                                    <?php if(!empty($service->service_image)): ?>
                                        <img src="<?php echo e(url($service->service_image)); ?>" style="border-radius:50%;width:40px;height:40px">
                                    <?php else: ?>
                                        ---
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($service->service_content); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/home/service/'.$service->id.'/delete')); ?>" onclick="return confirm('You want to delete <?php echo e($service->service_name); ?> service details.?')"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yhvreddy.com\resources\views/admin/services.blade.php ENDPATH**/ ?>