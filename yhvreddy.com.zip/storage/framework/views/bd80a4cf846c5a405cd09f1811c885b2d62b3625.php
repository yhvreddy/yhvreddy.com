<?php if(count($aboutdetails) != 0): ?>
    
    <?php $__env->startSection('page_title','Aboutus : : yhvreddy'); ?>
    <?php $__env->startSection('content_box'); ?>

    <?php $about = $aboutdetails[0]; ?>

        <section class="banner-area relative">
            <div class="container">
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            About Us
                        </h1>
                        <p class="link-nav">
                        <span class="box">
                            <a href="<?php echo e(url('/')); ?>">Home </a>
                            <a href="<?php echo e(url('/aboutus')); ?>">About</a></p>
                        </span>
                    </div>
                </div>
            </div>
        </section>

        <section class="about-area" style="padding:60px 0px 0px 0px">
            <div class="container">
                <div class="row align-items-center justify-content-between">
                    <div class="col-lg-6 about-left">
                         <?php if(!empty($about->about_img)): ?>
                            <img class="img-fluid" src="<?php echo e(asset($about->about_img)); ?>" alt="<?php echo e($about->first_name); ?>, Harshavardhan Reddy, Yenumula, yhvreddy">
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-5 col-md-12 about-right">
                        <div class="section-title">
                            <h2>about myselt</h2>
                        </div>
                        <div class="mb-50 wow fadeIn" data-wow-duration=".8s">
                            <?php if(!empty($about->short_description)): ?>
                                <?=$about->short_description?>
                            <?php else: ?>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
                                </p>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
                                </p>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(url('/aboutus')); ?>" class="primary-btn white" data-text="More Info">
                            <span>M</span>
                            <span>o</span>
                            <span>r</span>
                            <span>e</span>
                            <span> </span>
                            <span>I</span>
                            <span>n</span>
                            <span>f</span>
                            <span>o</span>
                        </a>
                        <?php if(!empty($about->resume)): ?>
                            <a href="<?php echo e(asset($about->resume)); ?>" target="_blank" class="primary-btn" data-text="Resume">
                                <span>R</span>
                                <span>e</span>
                                <span>s</span>
                                <span>u</span>
                                <span>m</span>
                                <span>e</span>
                            </a>
                        <?php endif; ?> 
                    </div>
                </div>
            </div>
        </section>

        <?php if(count($educations)): ?>
            <section class="job-area section-gap-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title">
                                <h2>Graduation History</h2>
                                <!-- <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price. You may see some for as low as $.17 each.</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <?php $bg = array('#e2a599','#715f69','#e45447','#90acd1'); ?>
                        <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-4">
                                <div class="single-job" style="background:<?php echo e($bg[$key]); ?>;color:#ffffff">
                                    <div class="top-sec d-flex justify-content-between">
                                        <div class="top-left">
                                            <h6><?php echo e($edu->education); ?></h6>
                                            <p>@ <?php echo e($edu->institute_name); ?> - <?php echo e($edu->university); ?> - <?php echo e($edu->pass_out); ?></p>
                                        </div>
                                    </div>
                                    <!-- <div class="bottom-sec wow fadeIn" data-wow-duration="2s">
                                        <span>University : </span> <?php echo e($edu->university); ?> @ <?php echo e($edu->pass_out); ?>

                                    </div> -->
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <?php if(count($experences) != 0): ?>
            <section class="job-area section-gap-top section-gap-bottom-90">
                <div class="container">
                    <div class="row d-flex">
                        <div class="col-lg-12">
                            <div class="section-title">
                                <h2>Job History</h2>
                                <!-- <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price. You may see some for as low as $.17 each.</p> -->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $experences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6">
                                <div class="single-job">
                                    <div class="top-sec d-flex justify-content-between">
                                        <div class="top-left">
                                            <h4><?php echo e($experence->company_name); ?></h4>
                                            <p><?php echo e($experence->location); ?></p>
                                        </div>
                                        <div class="top-right">
                                            <a href="#" class="primary-btn" data-text="Jul '15 to Present">
                                                <span>J</span><span>u</span><span>l</span>
                                                <span>'</span><span>1</span><span>5</span>
                                                <span>t</span><span>o</span>
                                                <span>P</span><span>r</span><span>e</span><span>s</span><span>e</span><span>n</span><span>t</span>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="bottom-sec wow fadeIn" data-wow-duration="2s">
                                        <?php echo e($experence->content); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

    <?php $__env->stopSection(); ?>
<?php else: ?>

<?php endif; ?>
<?php echo $__env->make('website_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yhvreddy.com\resources\views/aboutus_page.blade.php ENDPATH**/ ?>