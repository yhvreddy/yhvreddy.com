<?php $__env->startSection('page_title','Skills Details'); ?>
<?php $__env->startSection('content_box'); ?>
<div class="row">
    <div class="col-12 col-md-4 col-lg-4">
        <div class="card">
            <form method="post" action="<?php echo e(url('/home/saveSkills')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card-header">
                    <h4>Add Skills</h4>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label>Skill Name</label>
                        <input type="text" class="form-control" required="" name="skillName" placeholder="Add Skill Ex: PHP, MYSQL, ETC..">
                    </div>
                    <div class="form-group">
                        <label>Experence</label>
                        <input type="text" class="form-control" required="" name="experence" placeholder="Experence Ex: 1-M, 5-Y">
                    </div>
                    <div class="form-group">
                        <label>Rating</label>
                        <input type="tel" class="form-control" required="" min="1" maxlength="5" name="rating" placeholder="Rating Ex: 1-5">
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button class="btn btn-primary" type="submit">Save Skills</button>
                </div>
            </form>
        </div>
    </div>

    <div class="col-12 col-md-8 col-lg-8">
        <div class="card">
            
            <div class="card-header">
                <h4>Skills List</h4>
            </div>
            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped datatable" id="table-1">
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th>Skill Name</th>
                            <th>Experence</th>
                            <th>Rating</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td align="center"><?php echo e($key+1); ?></td>
                                <td><?php echo e($skill->name); ?></td>
                                <td>
                                    <?php $exp = explode('-',$skill->experience); ?>
                                    <?php echo e($exp['0']); ?>

                                    <?php echo e($exp['1']); ?>

                                </td>
                                <td><?php echo e($skill->rating); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/home/skills/'.$skill->id.'/delete')); ?>" onclick="return confirm('You want to delete <?php echo e($skill->name); ?> details.?')"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yhvreddy.com\resources\views/admin/skills_add.blade.php ENDPATH**/ ?>