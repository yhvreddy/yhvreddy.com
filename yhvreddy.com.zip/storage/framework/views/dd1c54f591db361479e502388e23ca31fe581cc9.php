<?php if(count($aboutdetails) != 0): ?>
    
    <?php $__env->startSection('page_title','Contactus : : yhvreddy'); ?>
    <?php $__env->startSection('content_box'); ?>
    <section class="banner-area relative">
        <div class="container">
            <div class="row d-flex align-items-center justify-content-center">
                <div class="about-content col-lg-12">
                    <h1 class="text-white">
                        Contact Us
                    </h1>
                    <p class="link-nav">
                        <span class="box">
                            <a href="<?php echo e(url('/')); ?>">Home </a>
                            <a href="<?php echo e(url('/contactus')); ?>">Contactus</a>
                        </span>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="contact-page-area" style="padding:50px 0px 0px 0px">
        <div class="container">
            <div class="row d-flex justify-content-between align-items-end">
                <div class="col-lg-6">
                    <div class="section-title">
                        <h2>Contactus </h2>
                        <!-- <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price. You may see
                            some for as low as $.17 each.</p> -->
                    </div>
                </div>
                <div class="col-lg-6">
                    <!-- <div class="filters">
                        <ul>
                            <li class="active" data-filter=".all">All Categories</li>
                            <li data-filter=".branding">Branding</li>
                            <li data-filter=".creative">Creative Work</li>
                            <li data-filter=".web-design">Web Design</li>
                        </ul>
                    </div> -->
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 d-flex flex-column address-wrap">
                    <!-- <div class="single-contact-address d-flex flex-row">
                        <div class="icon">
                            <span class="lnr lnr-home"></span>
                        </div>
                        <div class="contact-details">
                            <h5>Binghamton, New York</h5>
                            <p>
                                4343 Hinkle Deegan Lake Road
                            </p>
                        </div>
                    </div> -->
                    <div class="single-contact-address d-flex flex-row">
                        <div class="icon">
                            <span class="lnr lnr-phone-handset"></span>
                        </div>
                        <div class="contact-details">
                            <h5>+91 <?php echo e($aboutdetails[0]->mobile); ?></h5>
                            <p></p>
                        </div>
                    </div>
                    <div class="single-contact-address d-flex flex-row">
                        <div class="icon">
                            <span class="lnr lnr-envelope"></span>
                        </div>
                        <div class="contact-details">
                            <h5><a href="mailto:<?php echo e($aboutdetails[0]->email); ?>"><?php echo e($aboutdetails[0]->email); ?></a></h5>
                            <p>Send us your query anytime..!</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <form class="form-area " id="myForm" action="" method="post" class="contact-form text-right">
                        <div class="row">
                            <div class="col-lg-6 form-group form-group-top">
                                <input name="name" placeholder="Enter your name" onfocus="if (!window.__cfRLUnblockHandlers) return false; this.placeholder = ''" onblur="if (!window.__cfRLUnblockHandlers) return false; this.placeholder = 'Enter your name'" class="common-input mb-20 form-control" required="" type="text" data-cf-modified-1ee3e70e4a07ebd031f7619a-="">
                                <input name="email" placeholder="Enter email address" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$" onfocus="if (!window.__cfRLUnblockHandlers) return false; this.placeholder = ''" onblur="if (!window.__cfRLUnblockHandlers) return false; this.placeholder = 'Enter email address'" class="common-input mb-20 form-control" required="" type="email" data-cf-modified-1ee3e70e4a07ebd031f7619a-="">
                                <input name="subject" placeholder="Enter your subject" onfocus="if (!window.__cfRLUnblockHandlers) return false; this.placeholder = ''" onblur="if (!window.__cfRLUnblockHandlers) return false; this.placeholder = 'Enter your subject'" class="common-input mb-20 form-control" required="" type="text" data-cf-modified-1ee3e70e4a07ebd031f7619a-="">
                            </div>
                            <div class="col-lg-6 form-group">
                                <textarea class="common-textarea form-control" name="message" placeholder="Messege" onfocus="if (!window.__cfRLUnblockHandlers) return false; this.placeholder = ''" onblur="if (!window.__cfRLUnblockHandlers) return false; this.placeholder = 'Messege'" required="" data-cf-modified-1ee3e70e4a07ebd031f7619a-=""></textarea>
                            </div>
                            <div class="col-lg-12">
                                <div class="alert-msg" style="text-align: left;"></div>
                                <button class="primary-btn" style="float: right;" data-text="Send Message">
                                    <span>S</span>
                                    <span>e</span>
                                    <span>n</span>
                                    <span>d</span>
                                    <span> </span>
                                    <span>M</span>
                                    <span>e</span>
                                    <span>s</span>
                                    <span>s</span>
                                    <span>a</span>
                                    <span>g</span>
                                    <span>e</span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-lg-12">
                    <div class="map-wrap" style="width:100%; height: 445px;" id="map"></div>
                </div>
            </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php else: ?>

<?php endif; ?>
<?php echo $__env->make('website_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yhvreddy.com\resources\views/contactus_page.blade.php ENDPATH**/ ?>